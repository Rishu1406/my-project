import { useEffect, useState } from 'react';
import { Link,useLocation,useNavigate } from 'react-router-dom';
import EmployeeService from '../Service/EmployeeService';

const EmployeesList = () => {
    const [loading, setLoading] = useState(true);
    const [check,setCheck]=useState(false);
    const [employees, setEmployees] = useState(null);
    const location=useLocation();
    const navigate=useNavigate();
    const func1={name:'adding',id:0};
    const func2={name:'update',id:0};
    useEffect(() => {

        const fetchData = async () => {
            setLoading(true);
            try {
                const response = await EmployeeService.getEmployee();
                console.log(response.data);
                setEmployees(response.data);
            }
            catch (error) {
                console.error(error);
            }
            setLoading(false);

        }
        fetchData();

    }, [location.pathname,check]);

    const handleDelete=(id)=>{
        EmployeeService.deleteEmployee(id)
        .then((res)=>{console.log(res);
            setCheck(!check);
        })
        .catch((e)=>console.error(e));
    }

    return (
        <>
            <div className="container">
                <button onClick={()=>navigate("/addEmployee",{state:func1})} className="btn btn-primary bn-sl mt-5 mb-1">Add Employee</button>
                <table className="table table-responsive table-bordered table-striped table-hover text-center">
                    <thead className="table-dark">
                        <tr>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th className="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {employees && employees.length > 0 ? (
                            employees.map((emp) => (

                                <tr key={emp.id}>
                                    <td>{emp.name}</td>
                                    <td>{emp.phone}</td>
                                    <td>{emp.email}</td>
                                    <td>
                                        <button onClick={(e)=>{func2.id=emp.id; navigate("/addEmployee",{state:func2})}} className="btn btn-success btn-sm me-2">Update</button>
                                        <button onClick={(e)=>handleDelete(emp.id)} className="btn btn-danger btn-sm me-2">Delete</button>
                                    </td>
                                </tr>

                            ))
                        ) :
                            (
                                <tr>
                                    <td>No values found</td>
                                </tr>
                            )

                        }



                        {/* <tr>
                            <td>Mayank</td>
                            <td>809809</td>
                            <td>mma@gmail.com</td>
                            
                        </tr> */}
                    </tbody>
                </table>
            </div>
        </>
    );
};

export default EmployeesList;

// 
// 