import { useState } from "react";
import { useNavigate,useLocation } from "react-router-dom";
import EmployeeService from "../Service/EmployeeService";

const AddEmployee = () => {
const [employee,setEmployee]=useState({name:"",email:"",phone:""});
const navigate=useNavigate();
const location=useLocation();
const func=location.state;
const handleChange=(e)=>{
    setEmployee((prev)=>({
        ...prev,
        [e.target.name]:e.target.value
    }));
};

const handleAdding=(e)=>{
    e.preventDefault();
    EmployeeService.saveEmployee(employee)
    .then((res)=>console.log(res))
    .catch((e)=>console.error(e));
    setEmployee({name:"",email:"",phone:""});
    navigate("/");
}

const handleUpdate=(id)=>{
    EmployeeService.updateEmployee(id,employee)
    .then((res)=>console.log(res))
    .catch((e)=>console.error(e));
    setEmployee({name:"",email:"",phone:""});
    navigate("/");
}

    return (
        <div className="container-fluid d-flex justify-content-center  align-items-center vh-100">
            <form className="form-responsive border border-dark p-4 rounded ">
                <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input type="text" name="name" className="form-control" value={employee.name} onChange={handleChange}/><br />
                </div>
                <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input type="email" name="email" className="form-control" value={employee.email} onChange={handleChange}/><br />
                </div>
                <div className="mb-3">
                    <label className="form-label">Phone</label>
                    <input type="text" name="phone" className="form-control" value={employee.phone} onChange={handleChange}/><br />
                </div>
                <button type="submit" onClick={(func.name==="adding")?handleAdding:()=>handleUpdate(func.id)} className="btn btn-primary w-100">
                    {(func.name==="adding")?"Add Employee":"Update Employee"}
                </button>
            </form>
        </div>
    );
};

export default AddEmployee;