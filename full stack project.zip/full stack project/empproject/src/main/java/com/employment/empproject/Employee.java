package com.employment.empproject;

import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor

@RequiredArgsConstructor

public class Employee {
    private Long id;
    private String name;
    private String email;
    private String phone;

}
