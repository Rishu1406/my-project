package com.employment.empproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpprojectApplication.class, args);
	}

}
